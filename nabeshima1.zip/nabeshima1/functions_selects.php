<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
</body>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd">

<html><head>
<style type="text/css">
body {background-color: #ffffff; color: #000000;}
body, td, th, h1, h2 {font-family: sans-serif;}
pre {margin: 0px; font-family: monospace;}
a:link {color: #000099; text-decoration: none; background-color: #ffffff;}
a:hover {text-decoration: underline;}
table {border-collapse: collapse;}
.center {text-align: center;}
.center table { margin-left: auto; margin-right: auto; text-align: left;}
.center th { text-align: center !important; }
td, th { border: 1px solid #000000; font-size: 75%; vertical-align: baseline;}
h1 {font-size: 150%;}
h2 {font-size: 125%;}
.p {text-align: left;}
.e {background-color: #ccccff; font-weight: bold; color: #000000;}
.h {background-color: #9999cc; font-weight: bold; color: #000000;}
.v {background-color: #cccccc; color: #000000;}
i {color: #666666; background-color: #cccccc;}
img {float: right; border: 0px;}
hr {width: 600px; background-color: #cccccc; border: 0px; height: 1px; color: #000000;}
</style>
<title>phpinfo()</title><meta name="ROBOTS" content="NOINDEX,NOFOLLOW,NOARCHIVE" /></head>
<body><div class="center">
<table border="0" cellpadding="3" width="600">
<tr class="h"><td>
<a href="http://www.php.net/"><img border="0" src="/multimania/fr/nabeshima1/functions_selects.php?=PHPE9568F34-D428-11d2-A769-00AA001ACF42" alt="PHP Logo" /></a><h1 class="p">PHP Version 4.4.9</h1>
</td></tr>
</table><br />
<table border="0" cellpadding="3" width="600">
<tr><td class="e">System </td><td class="v">Linux wmphpf01.tmm.cvsn.de 2.6 #1 SMP Tue Sep 21 06:28:04 EDT 2010 i686 </td></tr>
<tr><td class="e">Build Date </td><td class="v">Nov 16 2009 21:35:40 </td></tr>

<tr><td class="e">Configure Command </td><td class="v"> &#039;./configure&#039; &#039;--build=i686-redhat-linux-gnu&#039; &#039;--host=i686-redhat-linux-gnu&#039; &#039;--target=i386-redhat-linux-gnu&#039; &#039;--program-prefix=&#039; &#039;--prefix=/usr&#039; &#039;--exec-prefix=/usr&#039; &#039;--bindir=/usr/bin&#039; &#039;--sbindir=/usr/sbin&#039; &#039;--sysconfdir=/etc&#039; &#039;--datadir=/usr/share&#039; &#039;--includedir=/usr/include&#039; &#039;--libdir=/usr/lib&#039; &#039;--libexecdir=/usr/libexec&#039; &#039;--localstatedir=/var&#039; &#039;--sharedstatedir=/usr/com&#039; &#039;--mandir=/usr/share/man&#039; &#039;--infodir=/usr/share/info&#039; &#039;--bindir=/data/apache/cgi-bin&#039; &#039;--with-config-file-path=/etc/multimania&#039; &#039;--without-cli&#039; &#039;--without-pear&#039; &#039;--enable-safe-mode&#039; &#039;--enable-memory-limit&#039; &#039;--enable-trans-sid&#039; &#039;--enable-force-cgi-redirect&#039; &#039;--enable-bcmath&#039; &#039;--with-bz2=/usr&#039; &#039;--enable-calendar&#039; &#039;--with-dom=/usr&#039; &#039;--enable-ftp&#039; &#039;--with-gd=/usr&#039; &#039;--with-jpeg-dir=/usr&#039; &#039;--with-png-dir=/usr&#039; &#039;--with-ttf=/usr/include/freetype2/freetype&#039; &#039;--with-freetype-dir=/usr&#039; &#039;--enable-gd-native-ttf&#039; &#039;--with-xpm-dir=/usr&#039; &#039;--with-gettext&#039; &#039;--with-iconv&#039; &#039;--with-imap&#039; &#039;--with-imap-ssl=/usr&#039; &#039;--enable-mbstring=all&#039; &#039;--enable-mbregex&#039; &#039;--with-mcrypt=/usr&#039; &#039;--with-mhash&#039; &#039;--with-mime-magic&#039; &#039;--with-mysql=/usr&#039; &#039;--with-openssl=/usr&#039; &#039;--with-kerberos&#039; &#039;--with-pspell&#039; &#039;--enable-sockets&#039; &#039;--with-xmlrpc&#039; &#039;--enable-xslt&#039; &#039;--with-xslt-sablot&#039; &#039;--with-sablot-js=/usr&#039; &#039;--with-readline=/usr&#039; &#039;--with-zip&#039; &#039;--with-zlib=/usr&#039; &#039;--disable-posix&#039; </td></tr>

<tr><td class="e">Server API </td><td class="v">CGI </td></tr>
<tr><td class="e">Virtual Directory Support </td><td class="v">disabled </td></tr>
<tr><td class="e">Configuration File (php.ini) Path </td><td class="v">/etc/multimania/php.ini </td></tr>
<tr><td class="e">PHP API </td><td class="v">20020918 </td></tr>
<tr><td class="e">PHP Extension </td><td class="v">20020429 </td></tr>
<tr><td class="e">Zend Extension </td><td class="v">20050606 </td></tr>

<tr><td class="e">Debug Build </td><td class="v">no </td></tr>
<tr><td class="e">Zend Memory Manager </td><td class="v">enabled </td></tr>
<tr><td class="e">Thread Safety </td><td class="v">disabled </td></tr>
<tr><td class="e">Registered PHP Streams </td><td class="v">php, http, ftp, https, ftps, compress.bzip2, compress.zlib   </td></tr>
</table><br />
<table border="0" cellpadding="3" width="600">
<tr class="v"><td>
<a href="http://www.zend.com/"><img border="0" src="/multimania/fr/nabeshima1/functions_selects.php?=PHPE9568F35-D428-11d2-A769-00AA001ACF42" alt="Zend logo" /></a>
This program makes use of the Zend Scripting Language Engine:<br />Zend Engine v1.3.0, Copyright (c) 1998-2004 Zend Technologies

</td></tr>
</table><br />
<hr />
<h1><a href="/multimania/fr/nabeshima1/functions_selects.php?=PHPB8B5F2A0-3C92-11d3-A3A9-4C7B08C10000">PHP Credits</a></h1>
<hr />
<h1>Configuration</h1>
<h2>PHP Core</h2>
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>Directive</th><th>Local Value</th><th>Master Value</th></tr>
<tr><td class="e">allow_call_time_pass_reference</td><td class="v">On</td><td class="v">On</td></tr>

<tr><td class="e">allow_url_fopen</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">always_populate_raw_post_data</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">arg_separator.input</td><td class="v">&amp;</td><td class="v">&amp;</td></tr>
<tr><td class="e">arg_separator.output</td><td class="v">&amp;</td><td class="v">&amp;</td></tr>
<tr><td class="e">asp_tags</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">auto_append_file</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>

<tr><td class="e">auto_prepend_file</td><td class="v">/usr/share/php/mmp_lib/prepend.php</td><td class="v">/usr/share/php/mmp_lib/prepend.php</td></tr>
<tr><td class="e">browscap</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">default_charset</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">default_mimetype</td><td class="v">text/html</td><td class="v">text/html</td></tr>
<tr><td class="e">define_syslog_variables</td><td class="v">Off</td><td class="v">Off</td></tr>

<tr><td class="e">disable_classes</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">disable_functions</td><td class="v">chmod,highlight_file,diskfreespace,&nbsp;exec,&nbsp;passthru,&nbsp;system,&nbsp;popen,&nbsp;fsockopen,&nbsp;pfsockopen,&nbsp;show_source,&nbsp;php_uname,&nbsp;ini_get,&nbsp;ini_alter,&nbsp;ini_restore,&nbsp;ini_set,&nbsp;getrusage,&nbsp;mysql_list_dbs,&nbsp;get_current_user,&nbsp;set_time_limit,&nbsp;getmyuid,&nbsp;getmygid,&nbsp;getmypid,&nbsp;dl,&nbsp;leak,&nbsp;listen,&nbsp;chown,&nbsp;chmod,&nbsp;chgrp,&nbsp;realpath,&nbsp;tmpfile,&nbsp;link,&nbsp;mb_send_mail,&nbsp;stream_bucket_append,&nbsp;stream_bucket_make_writeable,&nbsp;stream_bucket_new,&nbsp;stream_bucket_prepend,&nbsp;stream_context_create,&nbsp;stream_context_get_default,&nbsp;stream_context_get_options,&nbsp;stream_context_set_option,&nbsp;stream_context_set_params,&nbsp;stream_copy_to_stream,&nbsp;stream_encoding,&nbsp;stream_filter_append,&nbsp;stream_filter_prepend,&nbsp;stream_filter_register,&nbsp;stream_filter_remove,&nbsp;stream_get_contents,&nbsp;stream_get_filters,&nbsp;stream_get_line,&nbsp;stream_get_meta_data,&nbsp;stream_get_transports,&nbsp;stream_get_wrappers,&nbsp;stream_register_wrapper,&nbsp;stream_resolve_include_path,&nbsp;stream_select,&nbsp;stream_set_blocking,&nbsp;stream_set_timeout,&nbsp;stream_set_write_buffer,&nbsp;stream_socket_accept,&nbsp;stream_socket_client,&nbsp;stream_socket_enable_crypto,&nbsp;stream_socket_get_name,&nbsp;stream_socket_pair,&nbsp;stream_socket_recvfrom,&nbsp;stream_socket_sendto,&nbsp;stream_socket_server,&nbsp;stream_socket_shutdown,&nbsp;stream_wrapper_register,&nbsp;stream_wrapper_restore,&nbsp;stream_wrapper_unregister,&nbsp;shell_exec,&nbsp;error_log,&nbsp;openlog,&nbsp;syslog,&nbsp;apache_child_terminate,&nbsp;apache_get_modules,&nbsp;apache_get_version,&nbsp;apache_getenv,&nbsp;apache_note,&nbsp;apache_setenv,&nbsp;virtual,&nbsp;socket_create,&nbsp;socket_write,&nbsp;socket_bind,&nbsp;socket_select,&nbsp;pcntl_exec,&nbsp;proc_nice,&nbsp;proc_open,&nbsp;proc_terminate,&nbsp;pfsockopenproc_nice</td><td class="v">chmod,highlight_file,diskfreespace,&nbsp;exec,&nbsp;passthru,&nbsp;system,&nbsp;popen,&nbsp;fsockopen,&nbsp;pfsockopen,&nbsp;show_source,&nbsp;php_uname,&nbsp;ini_get,&nbsp;ini_alter,&nbsp;ini_restore,&nbsp;ini_set,&nbsp;getrusage,&nbsp;mysql_list_dbs,&nbsp;get_current_user,&nbsp;set_time_limit,&nbsp;getmyuid,&nbsp;getmygid,&nbsp;getmypid,&nbsp;dl,&nbsp;leak,&nbsp;listen,&nbsp;chown,&nbsp;chmod,&nbsp;chgrp,&nbsp;realpath,&nbsp;tmpfile,&nbsp;link,&nbsp;mb_send_mail,&nbsp;stream_bucket_append,&nbsp;stream_bucket_make_writeable,&nbsp;stream_bucket_new,&nbsp;stream_bucket_prepend,&nbsp;stream_context_create,&nbsp;stream_context_get_default,&nbsp;stream_context_get_options,&nbsp;stream_context_set_option,&nbsp;stream_context_set_params,&nbsp;stream_copy_to_stream,&nbsp;stream_encoding,&nbsp;stream_filter_append,&nbsp;stream_filter_prepend,&nbsp;stream_filter_register,&nbsp;stream_filter_remove,&nbsp;stream_get_contents,&nbsp;stream_get_filters,&nbsp;stream_get_line,&nbsp;stream_get_meta_data,&nbsp;stream_get_transports,&nbsp;stream_get_wrappers,&nbsp;stream_register_wrapper,&nbsp;stream_resolve_include_path,&nbsp;stream_select,&nbsp;stream_set_blocking,&nbsp;stream_set_timeout,&nbsp;stream_set_write_buffer,&nbsp;stream_socket_accept,&nbsp;stream_socket_client,&nbsp;stream_socket_enable_crypto,&nbsp;stream_socket_get_name,&nbsp;stream_socket_pair,&nbsp;stream_socket_recvfrom,&nbsp;stream_socket_sendto,&nbsp;stream_socket_server,&nbsp;stream_socket_shutdown,&nbsp;stream_wrapper_register,&nbsp;stream_wrapper_restore,&nbsp;stream_wrapper_unregister,&nbsp;shell_exec,&nbsp;error_log,&nbsp;openlog,&nbsp;syslog,&nbsp;apache_child_terminate,&nbsp;apache_get_modules,&nbsp;apache_get_version,&nbsp;apache_getenv,&nbsp;apache_note,&nbsp;apache_setenv,&nbsp;virtual,&nbsp;socket_create,&nbsp;socket_write,&nbsp;socket_bind,&nbsp;socket_select,&nbsp;pcntl_exec,&nbsp;proc_nice,&nbsp;proc_open,&nbsp;proc_terminate,&nbsp;pfsockopenproc_nice</td></tr>

<tr><td class="e">display_errors</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">display_startup_errors</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">doc_root</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">docref_ext</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">docref_root</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>

<tr><td class="e">enable_dl</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">error_append_string</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">error_log</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">error_prepend_string</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">error_reporting</td><td class="v">2037</td><td class="v">2037</td></tr>

<tr><td class="e">expose_php</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">extension_dir</td><td class="v">./</td><td class="v">./</td></tr>
<tr><td class="e">file_uploads</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">gpc_order</td><td class="v">GPC</td><td class="v">GPC</td></tr>
<tr><td class="e">highlight.bg</td><td class="v"><font style="color: #FFFFFF">#FFFFFF</font></td><td class="v"><font style="color: #FFFFFF">#FFFFFF</font></td></tr>

<tr><td class="e">highlight.comment</td><td class="v"><font style="color: #FF8000">#FF8000</font></td><td class="v"><font style="color: #FF8000">#FF8000</font></td></tr>
<tr><td class="e">highlight.default</td><td class="v"><font style="color: #0000BB">#0000BB</font></td><td class="v"><font style="color: #0000BB">#0000BB</font></td></tr>
<tr><td class="e">highlight.html</td><td class="v"><font style="color: #000000">#000000</font></td><td class="v"><font style="color: #000000">#000000</font></td></tr>
<tr><td class="e">highlight.keyword</td><td class="v"><font style="color: #007700">#007700</font></td><td class="v"><font style="color: #007700">#007700</font></td></tr>
<tr><td class="e">highlight.string</td><td class="v"><font style="color: #DD0000">#DD0000</font></td><td class="v"><font style="color: #DD0000">#DD0000</font></td></tr>

<tr><td class="e">html_errors</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">ignore_repeated_errors</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">ignore_repeated_source</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">ignore_user_abort</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">implicit_flush</td><td class="v">Off</td><td class="v">Off</td></tr>

<tr><td class="e">include_path</td><td class="v">.:/usr/share/php/mmp_lib</td><td class="v">.:/usr/share/php/mmp_lib</td></tr>
<tr><td class="e">log_errors</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">log_errors_max_len</td><td class="v">1024</td><td class="v">1024</td></tr>
<tr><td class="e">magic_quotes_gpc</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">magic_quotes_runtime</td><td class="v">Off</td><td class="v">Off</td></tr>

<tr><td class="e">magic_quotes_sybase</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">max_execution_time</td><td class="v">10</td><td class="v">10</td></tr>
<tr><td class="e">max_input_nesting_level</td><td class="v">500</td><td class="v">500</td></tr>
<tr><td class="e">max_input_time</td><td class="v">-1</td><td class="v">-1</td></tr>
<tr><td class="e">memory_limit</td><td class="v">16777216</td><td class="v">16777216</td></tr>

<tr><td class="e">open_basedir</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">output_buffering</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">output_handler</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">post_max_size</td><td class="v">512000</td><td class="v">512000</td></tr>
<tr><td class="e">precision</td><td class="v">14</td><td class="v">14</td></tr>

<tr><td class="e">register_argc_argv</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">register_globals</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">report_memleaks</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">safe_mode</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">safe_mode_exec_dir</td><td class="v">/usr/share/php/safe_exec</td><td class="v">/usr/share/php/safe_exec</td></tr>

<tr><td class="e">safe_mode_gid</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">safe_mode_include_dir</td><td class="v">/usr/share/php/mmp_lib</td><td class="v">/usr/share/php/mmp_lib</td></tr>
<tr><td class="e">sendmail_from</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">sendmail_path</td><td class="v">/usr/sbin/sendmail&nbsp;-t&nbsp;-f&nbsp;tripod@mail-return.hpb.lyceu.net</td><td class="v">/usr/sbin/sendmail&nbsp;-t&nbsp;-f&nbsp;tripod@mail-return.hpb.lyceu.net</td></tr>

<tr><td class="e">serialize_precision</td><td class="v">100</td><td class="v">100</td></tr>
<tr><td class="e">short_open_tag</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">SMTP</td><td class="v">localhost</td><td class="v">localhost</td></tr>
<tr><td class="e">smtp_port</td><td class="v">25</td><td class="v">25</td></tr>
<tr><td class="e">sql.safe_mode</td><td class="v">Off</td><td class="v">Off</td></tr>

<tr><td class="e">track_errors</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">unserialize_callback_func</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">upload_max_filesize</td><td class="v">4000000</td><td class="v">4000000</td></tr>
<tr><td class="e">upload_tmp_dir</td><td class="v">/tmp</td><td class="v">/tmp</td></tr>
<tr><td class="e">user_dir</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>

<tr><td class="e">variables_order</td><td class="v">EGPCS</td><td class="v">EGPCS</td></tr>
<tr><td class="e">xmlrpc_error_number</td><td class="v">0</td><td class="v">0</td></tr>
<tr><td class="e">xmlrpc_errors</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">y2k_compliance</td><td class="v">Off</td><td class="v">Off</td></tr>
</table><br />

<h2><a name="module_bcmath">bcmath</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">BCMath support </td><td class="v">enabled </td></tr>
</table><br />
<h2><a name="module_bz2">bz2</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">BZip2 Support </td><td class="v">Enabled </td></tr>
<tr><td class="e">BZip2 Version </td><td class="v">1.0.3, 15-Feb-2005 </td></tr>
</table><br />

<h2><a name="module_calendar">calendar</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">Calendar support </td><td class="v">enabled </td></tr>
</table><br />
<h2><a name="module_ctype">ctype</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">ctype functions </td><td class="v">enabled </td></tr>
</table><br />
<h2><a name="module_domxml">domxml</a></h2>
<table border="0" cellpadding="3" width="600">

<tr><td class="e">DOM/XML </td><td class="v">enabled </td></tr>
<tr><td class="e">DOM/XML API Version </td><td class="v">20020815 </td></tr>
<tr><td class="e">libxml Version </td><td class="v">20626 </td></tr>
<tr><td class="e">HTML Support </td><td class="v">enabled </td></tr>
<tr><td class="e">XPath Support </td><td class="v">enabled </td></tr>
<tr><td class="e">XPointer Support </td><td class="v">enabled </td></tr>

</table><br />
<h2><a name="module_ftp">ftp</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">FTP support </td><td class="v">enabled </td></tr>
</table><br />
<h2><a name="module_gd">gd</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">GD Support </td><td class="v">enabled </td></tr>
<tr><td class="e">GD Version </td><td class="v">2.0 or higher </td></tr>

<tr><td class="e">FreeType Support </td><td class="v">enabled </td></tr>
<tr><td class="e">FreeType Linkage </td><td class="v">with freetype </td></tr>
<tr><td class="e">GIF Read Support </td><td class="v">enabled </td></tr>
<tr><td class="e">GIF Create Support </td><td class="v">enabled </td></tr>
<tr><td class="e">JPG Support </td><td class="v">enabled </td></tr>
<tr><td class="e">PNG Support </td><td class="v">enabled </td></tr>

<tr><td class="e">WBMP Support </td><td class="v">enabled </td></tr>
</table><br />
<h2><a name="module_gettext">gettext</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">GetText Support </td><td class="v">enabled </td></tr>
</table><br />
<h2><a name="module_iconv">iconv</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">iconv support </td><td class="v">enabled </td></tr>

<tr><td class="e">iconv implementation </td><td class="v">glibc </td></tr>
<tr><td class="e">iconv library version </td><td class="v">2.5 </td></tr>
</table><br />
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>Directive</th><th>Local Value</th><th>Master Value</th></tr>
<tr><td class="e">iconv.input_encoding</td><td class="v">ISO-8859-1</td><td class="v">ISO-8859-1</td></tr>
<tr><td class="e">iconv.internal_encoding</td><td class="v">ISO-8859-1</td><td class="v">ISO-8859-1</td></tr>

<tr><td class="e">iconv.output_encoding</td><td class="v">ISO-8859-1</td><td class="v">ISO-8859-1</td></tr>
</table><br />
<h2><a name="module_imap">imap</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">IMAP c-Client Version </td><td class="v">2004 </td></tr>
<tr><td class="e">SSL Support </td><td class="v">enabled </td></tr>
<tr><td class="e">Kerberos Support </td><td class="v">enabled </td></tr>

</table><br />
<h2><a name="module_mbstring">mbstring</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">Multibyte Support </td><td class="v">enabled </td></tr>
<tr><td class="e">Japanese support </td><td class="v">enabled </td></tr>
<tr><td class="e">Simplified chinese support </td><td class="v">enabled </td></tr>
<tr><td class="e">Traditional chinese support </td><td class="v">enabled </td></tr>
<tr><td class="e">Korean support </td><td class="v">enabled </td></tr>

<tr><td class="e">Russian support </td><td class="v">enabled </td></tr>
<tr><td class="e">Multibyte (japanese) regex support </td><td class="v">enabled </td></tr>
</table><br />
<table border="0" cellpadding="3" width="600">
<tr class="h"><th colspan="2">mbstring extension makes use of "streamable kanji code filter and converter", which is distributed under the GNU Lesser General Public License version 2.1.</th></tr>
</table><br />
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>Directive</th><th>Local Value</th><th>Master Value</th></tr>
<tr><td class="e">mbstring.detect_order</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>

<tr><td class="e">mbstring.encoding_translation</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">mbstring.func_overload</td><td class="v">0</td><td class="v">0</td></tr>
<tr><td class="e">mbstring.http_input</td><td class="v">pass</td><td class="v">pass</td></tr>
<tr><td class="e">mbstring.http_output</td><td class="v">pass</td><td class="v">pass</td></tr>
<tr><td class="e">mbstring.internal_encoding</td><td class="v">ISO-8859-1</td><td class="v">ISO-8859-1</td></tr>

<tr><td class="e">mbstring.language</td><td class="v">neutral</td><td class="v">neutral</td></tr>
<tr><td class="e">mbstring.substitute_character</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
</table><br />
<h2><a name="module_mcrypt">mcrypt</a></h2>
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>mcrypt support</th><th>enabled</th></tr>
<tr><td class="e">version </td><td class="v">&gt;= 2.4.x </td></tr>

<tr><td class="e">Supported ciphers </td><td class="v">cast-128 gost rijndael-128 twofish arcfour cast-256 loki97 rijndael-192 saferplus wake blowfish-compat des rijndael-256 serpent xtea blowfish enigma rc2 tripledes  </td></tr>
<tr><td class="e">Supported modes </td><td class="v">cbc cfb ctr ecb ncfb nofb ofb stream  </td></tr>
</table><br />
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>Directive</th><th>Local Value</th><th>Master Value</th></tr>
<tr><td class="e">mcrypt.algorithms_dir</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">mcrypt.modes_dir</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>

</table><br />
<h2><a name="module_mhash">mhash</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">MHASH support </td><td class="v">Enabled </td></tr>
<tr><td class="e">MHASH API Version </td><td class="v">20020524 </td></tr>
</table><br />
<h2><a name="module_mime_magic">mime_magic</a></h2>
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>mime_magic support</th><th>enabled</th></tr>

</table><br />
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>Directive</th><th>Local Value</th><th>Master Value</th></tr>
<tr><td class="e">mime_magic.magicfile</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
</table><br />
<h2><a name="module_mysql">mysql</a></h2>
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>MySQL Support</th><th>enabled</th></tr>

<tr><td class="e">Active Persistent Links </td><td class="v">0 </td></tr>
<tr><td class="e">Active Links </td><td class="v">0 </td></tr>
<tr><td class="e">Client API version </td><td class="v">5.0.77 </td></tr>
<tr><td class="e">MYSQL_MODULE_TYPE </td><td class="v">external </td></tr>
<tr><td class="e">MYSQL_SOCKET </td><td class="v">/var/lib/mysql/mysql.sock </td></tr>
<tr><td class="e">MYSQL_INCLUDE </td><td class="v">-I/usr/include/mysql </td></tr>

<tr><td class="e">MYSQL_LIBS </td><td class="v">-L/usr/lib/mysql -lmysqlclient  </td></tr>
</table><br />
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>Directive</th><th>Local Value</th><th>Master Value</th></tr>
<tr><td class="e">mysql.allow_persistent</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">mysql.connect_timeout</td><td class="v">60</td><td class="v">60</td></tr>

<tr><td class="e">mysql.default_host</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">mysql.default_password</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">mysql.default_port</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">mysql.default_socket</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">mysql.default_user</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>

<tr><td class="e">mysql.max_links</td><td class="v">3</td><td class="v">3</td></tr>
<tr><td class="e">mysql.max_persistent</td><td class="v">0</td><td class="v">0</td></tr>
<tr><td class="e">mysql.trace_mode</td><td class="v">Off</td><td class="v">Off</td></tr>
</table><br />
<h2><a name="module_openssl">openssl</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">OpenSSL support </td><td class="v">enabled </td></tr>

<tr><td class="e">OpenSSL Version </td><td class="v">OpenSSL 0.9.8e-fips-rhel5 01 Jul 2008 </td></tr>
</table><br />
<h2><a name="module_overload">overload</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">User-Space Object Overloading Support </td><td class="v">enabled </td></tr>
</table><br />
<h2><a name="module_pcre">pcre</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">PCRE (Perl Compatible Regular Expressions) Support </td><td class="v">enabled </td></tr>

<tr><td class="e">PCRE Library Version </td><td class="v">7.7 2008-05-07 </td></tr>
</table><br />
<h2><a name="module_pspell">pspell</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">PSpell Support </td><td class="v">enabled </td></tr>
</table><br />
<h2><a name="module_session">session</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">Session Support </td><td class="v">enabled </td></tr>

<tr><td class="e">Registered save handlers </td><td class="v">files user  </td></tr>
</table><br />
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>Directive</th><th>Local Value</th><th>Master Value</th></tr>
<tr><td class="e">session.auto_start</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">session.bug_compat_42</td><td class="v">On</td><td class="v">On</td></tr>

<tr><td class="e">session.bug_compat_warn</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">session.cache_expire</td><td class="v">180</td><td class="v">180</td></tr>
<tr><td class="e">session.cache_limiter</td><td class="v">nocache</td><td class="v">nocache</td></tr>
<tr><td class="e">session.cookie_domain</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">session.cookie_lifetime</td><td class="v">3600</td><td class="v">3600</td></tr>

<tr><td class="e">session.cookie_path</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">session.cookie_secure</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">session.entropy_file</td><td class="v">/dev/urandom</td><td class="v">/dev/urandom</td></tr>
<tr><td class="e">session.entropy_length</td><td class="v">16</td><td class="v">16</td></tr>
<tr><td class="e">session.gc_divisor</td><td class="v">100</td><td class="v">100</td></tr>

<tr><td class="e">session.gc_maxlifetime</td><td class="v">1200</td><td class="v">1200</td></tr>
<tr><td class="e">session.gc_probability</td><td class="v">0</td><td class="v">0</td></tr>
<tr><td class="e">session.name</td><td class="v">PHPSESSID</td><td class="v">PHPSESSID</td></tr>
<tr><td class="e">session.referer_check</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">session.save_handler</td><td class="v">files</td><td class="v">files</td></tr>

<tr><td class="e">session.save_path</td><td class="v">3;/data/session</td><td class="v">3;/data/session</td></tr>
<tr><td class="e">session.serialize_handler</td><td class="v">php</td><td class="v">php</td></tr>
<tr><td class="e">session.use_cookies</td><td class="v">On</td><td class="v">On</td></tr>
<tr><td class="e">session.use_only_cookies</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">session.use_trans_sid</td><td class="v">Off</td><td class="v">Off</td></tr>

</table><br />
<h2><a name="module_sockets">sockets</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">Sockets Support </td><td class="v">enabled </td></tr>
</table><br />
<h2><a name="module_standard">standard</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">Regex Library </td><td class="v">Bundled library enabled </td></tr>
<tr><td class="e">Dynamic Library Support </td><td class="v">enabled </td></tr>

<tr><td class="e">Path to sendmail </td><td class="v">/usr/sbin/sendmail -t -f tripod@mail-return.hpb.lyceu.net </td></tr>
</table><br />
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>Directive</th><th>Local Value</th><th>Master Value</th></tr>
<tr><td class="e">assert.active</td><td class="v">1</td><td class="v">1</td></tr>
<tr><td class="e">assert.bail</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>

<tr><td class="e">assert.callback</td><td class="v">0</td><td class="v">0</td></tr>
<tr><td class="e">assert.quiet_eval</td><td class="v">1</td><td class="v">1</td></tr>
<tr><td class="e">assert.warning</td><td class="v">1</td><td class="v">1</td></tr>
<tr><td class="e">auto_detect_line_endings</td><td class="v">0</td><td class="v">0</td></tr>
<tr><td class="e">default_socket_timeout</td><td class="v">60</td><td class="v">60</td></tr>

<tr><td class="e">safe_mode_allowed_env_vars</td><td class="v">PHP_</td><td class="v">PHP_</td></tr>
<tr><td class="e">safe_mode_protected_env_vars</td><td class="v">LD_LIBRARY_PATH</td><td class="v">LD_LIBRARY_PATH</td></tr>
<tr><td class="e">url_rewriter.tags</td><td class="v">a=href,area=href,frame=src,input=src,form=fakeentry</td><td class="v">a=href,area=href,frame=src,input=src,form=fakeentry</td></tr>
<tr><td class="e">user_agent</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>
</table><br />

<h2><a name="module_tokenizer">tokenizer</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">Tokenizer Support </td><td class="v">enabled </td></tr>
</table><br />
<h2><a name="module_xml">xml</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">XML Support </td><td class="v">active </td></tr>
<tr><td class="e">XML Namespace Support </td><td class="v">active </td></tr>
<tr><td class="e">EXPAT Version </td><td class="v">1.95.6 </td></tr>

</table><br />
<h2><a name="module_xmlrpc">xmlrpc</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">core library version </td><td class="v">xmlrpc-epi v. 0.51 </td></tr>
<tr><td class="e">php extension version </td><td class="v">0.51 </td></tr>
<tr><td class="e">author </td><td class="v">Dan Libby </td></tr>
<tr><td class="e">homepage </td><td class="v">http://xmlrpc-epi.sourceforge.net </td></tr>
<tr><td class="e">open sourced by </td><td class="v">Epinions.com </td></tr>

</table><br />
<h2><a name="module_xslt">xslt</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">XSLT support </td><td class="v">enabled </td></tr>
<tr><td class="e">Backend </td><td class="v">Sablotron </td></tr>
<tr><td class="e">Sablotron Version </td><td class="v">1.0.3 </td></tr>
<tr><td class="e">Sablotron Information </td><td class="v">Cflags: -O2 -g -pipe -Wall -Wp,-D_FORTIFY_SOURCE=2 -fexceptions -fstack-protector --param=ssp-buffer-size=4 -m32 -march=i386 -mtune=generic -fasynchronous-unwind-tables Libs: -L/usr/lib -lexpat -lncurses -lreadline -ljs Prefix: /usr </td></tr>
</table><br />

<h2><a name="module_zip">zip</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">Zip support </td><td class="v">enabled </td></tr>
</table><br />
<h2><a name="module_zlib">zlib</a></h2>
<table border="0" cellpadding="3" width="600">
<tr><td class="e">ZLib Support </td><td class="v">enabled </td></tr>
<tr><td class="e">Compiled Version </td><td class="v">1.2.3 </td></tr>
<tr><td class="e">Linked Version </td><td class="v">1.2.3 </td></tr>

</table><br />
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>Directive</th><th>Local Value</th><th>Master Value</th></tr>
<tr><td class="e">zlib.output_compression</td><td class="v">Off</td><td class="v">Off</td></tr>
<tr><td class="e">zlib.output_compression_level</td><td class="v">-1</td><td class="v">-1</td></tr>
<tr><td class="e">zlib.output_handler</td><td class="v"><i>no value</i></td><td class="v"><i>no value</i></td></tr>

</table><br />
<h2>Additional Modules</h2>
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>Module Name</th></tr>
<tr><td>readline</td></tr>
</table><br />
<h2>Environment</h2>
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>Variable</th><th>Value</th></tr>
<tr><td class="e">REDIRECT_SCRIPT_URL </td><td class="v">/multimania/fr/nabeshima1/functions_selects.php </td></tr>

<tr><td class="e">REDIRECT_SCRIPT_URI </td><td class="v">http://php-fr.tmm.cvsn.de/multimania/fr/nabeshima1/functions_selects.php </td></tr>
<tr><td class="e">REDIRECT_HANDLER </td><td class="v">application/x-httpd-php </td></tr>
<tr><td class="e">REDIRECT_STATUS </td><td class="v">200 </td></tr>
<tr><td class="e">SCRIPT_URL </td><td class="v">/multimania/fr/nabeshima1/functions_selects.php </td></tr>
<tr><td class="e">SCRIPT_URI </td><td class="v">http://php-fr.tmm.cvsn.de/multimania/fr/nabeshima1/functions_selects.php </td></tr>
<tr><td class="e">HTTP_HOST </td><td class="v">php-fr.tmm.cvsn.de </td></tr>

<tr><td class="e">HTTP_USER_AGENT </td><td class="v">Mozilla/5.0 (Windows NT 5.1; rv:7.0.1) Gecko/20100101 Firefox/7.0.1 </td></tr>
<tr><td class="e">HTTP_ACCEPT </td><td class="v">text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8 </td></tr>
<tr><td class="e">HTTP_ACCEPT_LANGUAGE </td><td class="v">fr,fr-fr;q=0.8,en-us;q=0.5,en;q=0.3 </td></tr>
<tr><td class="e">HTTP_ACCEPT_ENCODING </td><td class="v">gzip, deflate </td></tr>
<tr><td class="e">HTTP_ACCEPT_CHARSET </td><td class="v">ISO-8859-1,utf-8;q=0.7,*;q=0.7 </td></tr>
<tr><td class="e">HTTP_COOKIE </td><td class="v">mmad_slider=3:1320499933321; __utma=264340627.517081085.1304754635.1318156672.1320498055.8; __utmz=264340627.1304754635.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); LBC=8752d988494069d3d52c037db7009dd9; Apache=82.238.120.144.1320498044205864; __utmb=264340627.9.10.1320498055; __utmc=264340627 </td></tr>

<tr><td class="e">HTTP_X_FORWARDED_FOR </td><td class="v">82.238.120.144 </td></tr>
<tr><td class="e">HTTP_X_FORWARDED_HOST </td><td class="v">membres.multimania.fr </td></tr>
<tr><td class="e">HTTP_X_FORWARDED_SERVER </td><td class="v">membres.multimania.fr </td></tr>
<tr><td class="e">HTTP_CONNECTION </td><td class="v">close </td></tr>
<tr><td class="e">PATH </td><td class="v">/sbin:/usr/sbin:/bin:/usr/bin </td></tr>
<tr><td class="e">SERVER_SIGNATURE </td><td class="v">&lt;address&gt;Apache/2.2.3 (CentOS) Server at php-fr.tmm.cvsn.de Port 80&lt;/address&gt;

 </td></tr>
<tr><td class="e">SERVER_SOFTWARE </td><td class="v">Apache/2.2.3 (CentOS) </td></tr>
<tr><td class="e">SERVER_NAME </td><td class="v">php-fr.tmm.cvsn.de </td></tr>
<tr><td class="e">SERVER_ADDR </td><td class="v">213.131.252.250 </td></tr>
<tr><td class="e">SERVER_PORT </td><td class="v">80 </td></tr>
<tr><td class="e">REMOTE_ADDR </td><td class="v">213.131.252.130 </td></tr>

<tr><td class="e">DOCUMENT_ROOT </td><td class="v">/var/www/html </td></tr>
<tr><td class="e">SERVER_ADMIN </td><td class="v">webadmin-fr@lycos-europe.de </td></tr>
<tr><td class="e">SCRIPT_FILENAME </td><td class="v">/var/www/cgi-bin/php_free </td></tr>
<tr><td class="e">REMOTE_PORT </td><td class="v">33473 </td></tr>
<tr><td class="e">REDIRECT_URL </td><td class="v">/multimania/fr/nabeshima1/functions_selects.php </td></tr>
<tr><td class="e">GATEWAY_INTERFACE </td><td class="v">CGI/1.1 </td></tr>

<tr><td class="e">SERVER_PROTOCOL </td><td class="v">HTTP/1.1 </td></tr>
<tr><td class="e">REQUEST_METHOD </td><td class="v">GET </td></tr>
<tr><td class="e">QUERY_STRING </td><td class="v"><i>no value</i> </td></tr>
<tr><td class="e">REQUEST_URI </td><td class="v">/multimania/fr/nabeshima1/functions_selects.php </td></tr>
<tr><td class="e">SCRIPT_NAME </td><td class="v">/cgi-bin/php_free </td></tr>
<tr><td class="e">PATH_INFO </td><td class="v">/multimania/fr/nabeshima1/functions_selects.php </td></tr>

<tr><td class="e">PATH_TRANSLATED </td><td class="v">/data/members/free/multimania/fr/n/a/b/nabeshima1/htdocs/functions_selects.php </td></tr>
</table><br />
<h2>PHP Variables</h2>
<table border="0" cellpadding="3" width="600">
<tr class="h"><th>Variable</th><th>Value</th></tr>
<tr><td class="e">PHP_SELF </td><td class="v">/nabeshima1/functions_selects.php </td></tr>
<tr><td class="e">_REQUEST["mmad_slider"]</td><td class="v">3:1320499933321</td></tr>
<tr><td class="e">_REQUEST["__utma"]</td><td class="v">264340627.517081085.1304754635.1318156672.1320498055.8</td></tr>

<tr><td class="e">_REQUEST["__utmz"]</td><td class="v">264340627.1304754635.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)</td></tr>
<tr><td class="e">_REQUEST["LBC"]</td><td class="v">8752d988494069d3d52c037db7009dd9</td></tr>
<tr><td class="e">_REQUEST["Apache"]</td><td class="v">82.238.120.144.1320498044205864</td></tr>
<tr><td class="e">_REQUEST["__utmb"]</td><td class="v">264340627.9.10.1320498055</td></tr>
<tr><td class="e">_REQUEST["__utmc"]</td><td class="v">264340627</td></tr>
<tr><td class="e">_COOKIE["mmad_slider"]</td><td class="v">3:1320499933321</td></tr>

<tr><td class="e">_COOKIE["__utma"]</td><td class="v">264340627.517081085.1304754635.1318156672.1320498055.8</td></tr>
<tr><td class="e">_COOKIE["__utmz"]</td><td class="v">264340627.1304754635.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)</td></tr>
<tr><td class="e">_COOKIE["LBC"]</td><td class="v">8752d988494069d3d52c037db7009dd9</td></tr>
<tr><td class="e">_COOKIE["Apache"]</td><td class="v">82.238.120.144.1320498044205864</td></tr>
<tr><td class="e">_COOKIE["__utmb"]</td><td class="v">264340627.9.10.1320498055</td></tr>
<tr><td class="e">_COOKIE["__utmc"]</td><td class="v">264340627</td></tr>

<tr><td class="e">_SERVER["REDIRECT_SCRIPT_URL"]</td><td class="v">/nabeshima1/functions_selects.php</td></tr>
<tr><td class="e">_SERVER["REDIRECT_SCRIPT_URI"]</td><td class="v">http://membres.multimania.fr/nabeshima1/functions_selects.php</td></tr>
<tr><td class="e">_SERVER["REDIRECT_HANDLER"]</td><td class="v">application/x-httpd-php</td></tr>
<tr><td class="e">_SERVER["REDIRECT_STATUS"]</td><td class="v">200</td></tr>
<tr><td class="e">_SERVER["SCRIPT_URL"]</td><td class="v">/nabeshima1/functions_selects.php</td></tr>
<tr><td class="e">_SERVER["SCRIPT_URI"]</td><td class="v">http://membres.multimania.fr/nabeshima1/functions_selects.php</td></tr>

<tr><td class="e">_SERVER["HTTP_HOST"]</td><td class="v">membres.multimania.fr</td></tr>
<tr><td class="e">_SERVER["HTTP_USER_AGENT"]</td><td class="v">Mozilla/5.0 (Windows NT 5.1; rv:7.0.1) Gecko/20100101 Firefox/7.0.1</td></tr>
<tr><td class="e">_SERVER["HTTP_ACCEPT"]</td><td class="v">text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8</td></tr>
<tr><td class="e">_SERVER["HTTP_ACCEPT_LANGUAGE"]</td><td class="v">fr,fr-fr;q=0.8,en-us;q=0.5,en;q=0.3</td></tr>
<tr><td class="e">_SERVER["HTTP_ACCEPT_CHARSET"]</td><td class="v">ISO-8859-1,utf-8;q=0.7,*;q=0.7</td></tr>
<tr><td class="e">_SERVER["HTTP_COOKIE"]</td><td class="v">mmad_slider=3:1320499933321; __utma=264340627.517081085.1304754635.1318156672.1320498055.8; __utmz=264340627.1304754635.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); LBC=8752d988494069d3d52c037db7009dd9; Apache=82.238.120.144.1320498044205864; __utmb=264340627.9.10.1320498055; __utmc=264340627</td></tr>

<tr><td class="e">_SERVER["HTTP_X_FORWARDED_FOR"]</td><td class="v">82.238.120.144</td></tr>
<tr><td class="e">_SERVER["HTTP_X_FORWARDED_HOST"]</td><td class="v">membres.multimania.fr</td></tr>
<tr><td class="e">_SERVER["HTTP_CONNECTION"]</td><td class="v">close</td></tr>
<tr><td class="e">_SERVER["PATH"]</td><td class="v">/sbin:/usr/sbin:/bin:/usr/bin</td></tr>
<tr><td class="e">_SERVER["SERVER_SIGNATURE"]</td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">_SERVER["SERVER_SOFTWARE"]</td><td class="v">Apache (UNIX)</td></tr>

<tr><td class="e">_SERVER["SERVER_NAME"]</td><td class="v">membres.multimania.fr</td></tr>
<tr><td class="e">_SERVER["SERVER_ADDR"]</td><td class="v">213.131.252.250</td></tr>
<tr><td class="e">_SERVER["SERVER_PORT"]</td><td class="v">80</td></tr>
<tr><td class="e">_SERVER["REMOTE_ADDR"]</td><td class="v">82.238.120.144</td></tr>
<tr><td class="e">_SERVER["DOCUMENT_ROOT"]</td><td class="v">/data/members/free/multimania/fr/n/a/b/nabeshima1/htdocs/</td></tr>
<tr><td class="e">_SERVER["SERVER_ADMIN"]</td><td class="v">webadmin-fr@lycos-europe.de</td></tr>

<tr><td class="e">_SERVER["SCRIPT_FILENAME"]</td><td class="v">/data/members/free/multimania/fr/n/a/b/nabeshima1/htdocs/functions_selects.php</td></tr>
<tr><td class="e">_SERVER["REMOTE_PORT"]</td><td class="v">33473</td></tr>
<tr><td class="e">_SERVER["REDIRECT_URL"]</td><td class="v">/nabeshima1/functions_selects.php</td></tr>
<tr><td class="e">_SERVER["GATEWAY_INTERFACE"]</td><td class="v">CGI/1.1</td></tr>
<tr><td class="e">_SERVER["SERVER_PROTOCOL"]</td><td class="v">HTTP/1.1</td></tr>
<tr><td class="e">_SERVER["REQUEST_METHOD"]</td><td class="v">GET</td></tr>

<tr><td class="e">_SERVER["QUERY_STRING"]</td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">_SERVER["REQUEST_URI"]</td><td class="v">/nabeshima1/functions_selects.php</td></tr>
<tr><td class="e">_SERVER["SCRIPT_NAME"]</td><td class="v">functions_selects.php</td></tr>
<tr><td class="e">_SERVER["PATH_INFO"]</td><td class="v">/nabeshima1/functions_selects.php</td></tr>
<tr><td class="e">_SERVER["PATH_TRANSLATED"]</td><td class="v">/data/members/free/multimania/fr/n/a/b/nabeshima1/htdocs/functions_selects.php</td></tr>
<tr><td class="e">_SERVER["PHP_SELF"]</td><td class="v">/nabeshima1/functions_selects.php</td></tr>

<tr><td class="e">_SERVER["argv"]</td><td class="v"><pre>Array
(
)
</pre></td></tr>
<tr><td class="e">_SERVER["argc"]</td><td class="v">0</td></tr>
<tr><td class="e">_ENV["REDIRECT_SCRIPT_URL"]</td><td class="v">/nabeshima1/functions_selects.php</td></tr>
<tr><td class="e">_ENV["REDIRECT_SCRIPT_URI"]</td><td class="v">http://membres.multimania.fr/nabeshima1/functions_selects.php</td></tr>
<tr><td class="e">_ENV["REDIRECT_HANDLER"]</td><td class="v">application/x-httpd-php</td></tr>
<tr><td class="e">_ENV["REDIRECT_STATUS"]</td><td class="v">200</td></tr>

<tr><td class="e">_ENV["SCRIPT_URL"]</td><td class="v">/nabeshima1/functions_selects.php</td></tr>
<tr><td class="e">_ENV["SCRIPT_URI"]</td><td class="v">http://membres.multimania.fr/nabeshima1/functions_selects.php</td></tr>
<tr><td class="e">_ENV["HTTP_HOST"]</td><td class="v">membres.multimania.fr</td></tr>
<tr><td class="e">_ENV["HTTP_USER_AGENT"]</td><td class="v">Mozilla/5.0 (Windows NT 5.1; rv:7.0.1) Gecko/20100101 Firefox/7.0.1</td></tr>
<tr><td class="e">_ENV["HTTP_ACCEPT"]</td><td class="v">text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8</td></tr>
<tr><td class="e">_ENV["HTTP_ACCEPT_LANGUAGE"]</td><td class="v">fr,fr-fr;q=0.8,en-us;q=0.5,en;q=0.3</td></tr>

<tr><td class="e">_ENV["HTTP_ACCEPT_ENCODING"]</td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">_ENV["HTTP_ACCEPT_CHARSET"]</td><td class="v">ISO-8859-1,utf-8;q=0.7,*;q=0.7</td></tr>
<tr><td class="e">_ENV["HTTP_COOKIE"]</td><td class="v">mmad_slider=3:1320499933321; __utma=264340627.517081085.1304754635.1318156672.1320498055.8; __utmz=264340627.1304754635.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); LBC=8752d988494069d3d52c037db7009dd9; Apache=82.238.120.144.1320498044205864; __utmb=264340627.9.10.1320498055; __utmc=264340627</td></tr>
<tr><td class="e">_ENV["HTTP_X_FORWARDED_FOR"]</td><td class="v">82.238.120.144</td></tr>
<tr><td class="e">_ENV["HTTP_X_FORWARDED_HOST"]</td><td class="v">membres.multimania.fr</td></tr>
<tr><td class="e">_ENV["HTTP_X_FORWARDED_SERVER"]</td><td class="v"><i>no value</i></td></tr>

<tr><td class="e">_ENV["HTTP_CONNECTION"]</td><td class="v">close</td></tr>
<tr><td class="e">_ENV["PATH"]</td><td class="v">/sbin:/usr/sbin:/bin:/usr/bin</td></tr>
<tr><td class="e">_ENV["SERVER_SIGNATURE"]</td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">_ENV["SERVER_SOFTWARE"]</td><td class="v">Apache (UNIX)</td></tr>
<tr><td class="e">_ENV["SERVER_NAME"]</td><td class="v">membres.multimania.fr</td></tr>
<tr><td class="e">_ENV["SERVER_ADDR"]</td><td class="v">213.131.252.250</td></tr>

<tr><td class="e">_ENV["SERVER_PORT"]</td><td class="v">80</td></tr>
<tr><td class="e">_ENV["REMOTE_ADDR"]</td><td class="v">82.238.120.144</td></tr>
<tr><td class="e">_ENV["DOCUMENT_ROOT"]</td><td class="v">/data/members/free/multimania/fr/n/a/b/nabeshima1/htdocs/</td></tr>
<tr><td class="e">_ENV["SERVER_ADMIN"]</td><td class="v">webadmin-fr@lycos-europe.de</td></tr>
<tr><td class="e">_ENV["SCRIPT_FILENAME"]</td><td class="v">/data/members/free/multimania/fr/n/a/b/nabeshima1/htdocs/functions_selects.php</td></tr>
<tr><td class="e">_ENV["REMOTE_PORT"]</td><td class="v">33473</td></tr>

<tr><td class="e">_ENV["REDIRECT_URL"]</td><td class="v">/nabeshima1/functions_selects.php</td></tr>
<tr><td class="e">_ENV["GATEWAY_INTERFACE"]</td><td class="v">CGI/1.1</td></tr>
<tr><td class="e">_ENV["SERVER_PROTOCOL"]</td><td class="v">HTTP/1.1</td></tr>
<tr><td class="e">_ENV["REQUEST_METHOD"]</td><td class="v">GET</td></tr>
<tr><td class="e">_ENV["QUERY_STRING"]</td><td class="v"><i>no value</i></td></tr>
<tr><td class="e">_ENV["REQUEST_URI"]</td><td class="v">/nabeshima1/functions_selects.php</td></tr>

<tr><td class="e">_ENV["SCRIPT_NAME"]</td><td class="v">functions_selects.php</td></tr>
<tr><td class="e">_ENV["PATH_INFO"]</td><td class="v">/nabeshima1/functions_selects.php</td></tr>
<tr><td class="e">_ENV["PATH_TRANSLATED"]</td><td class="v">/data/members/free/multimania/fr/n/a/b/nabeshima1/htdocs/functions_selects.php</td></tr>
</table><br />
<h2>PHP License</h2>
<table border="0" cellpadding="3" width="600">
<tr class="v"><td>
<p>
This program is free software; you can redistribute it and/or modify it under the terms of the PHP License as published by the PHP Group and included in the distribution in the file:  LICENSE
</p>

<p>This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
</p>
<p>If you did not receive a copy of the PHP license, or have any questions about PHP licensing, please contact license@php.net.
</p>
</td></tr>
</table><br />
</div></body></html> 